public class TransformarString implements Transformer<String,String>{
	/**
	 * funcion que toma un string y lo convierte en string
	 * @param input string que se convertira a string
	 * @return string convertido
	 */
	public String transform(String input){
		String dato = input;
		return dato;
	}

}